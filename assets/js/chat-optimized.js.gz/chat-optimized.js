class SVTRChat{
  constructor(e){
    this.container=document.getElementById(e),this.messages=[],this.isLoading=!1,this.isThinking=!1,this.apiEndpoint='/api/chat',this.isProduction=this.detectProductionEnvironment(),this.quotaWarningShown=!1,this.sessionId=this.getOrCreateSessionId(),this.init();
  }getOrCreateSessionId(){
    let e=localStorage.getItem('svtr_session_id');return e||(e=`session_${Date.now()}_${Math.random().toString(36).substr(2,9)}`,localStorage.setItem('svtr_session_id',e)),e;
  }detectProductionEnvironment(){
    const e='localhost'===window.location.hostname&&'3000'===window.location.port;return'localhost'!==window.location.hostname&&'127.0.0.1'!==window.location.hostname||e;
  }async tryRealAPIFirst(e,n){
    try{
      const e=await fetch(this.apiEndpoint,{method:'POST',headers:{'Content-Type':'application/json','x-session-id':this.sessionId},body:JSON.stringify({messages:this.messages.filter(e=>'system'!==e.role)})});if(e.ok){
        return this.handleStreamingResponse(e,n),!0;
      }
    }catch(e){
      console.log('Real API not available, using smart demo mode');
    }return!1;
  }async handleStreamingResponse(e,n){
    const t=e.body.getReader(),s=new TextDecoder,a={role:'assistant',content:'',timestamp:new Date};let i=null,o=null,r=!1;try{
      for(;;){
        const{done:e,value:c}=await t.read();if(e){
          break;
        }const l=s.decode(c,{stream:!0}).split('\n');for(const e of l){
          if(e.trim()&&e.startsWith('data: ')){
            try{
              const t=e.slice(6).trim();if('[DONE]'===t){
                break;
              }const s=JSON.parse(t);if(s.response&&'string'===typeof s.response){
                const e=/\d/.test(s.response);e&&(console.log('🔢 收到包含数字的响应片段:',s.response),console.log('🔢 提取的数字:',s.response.match(/\d+/g))),r||(this.removeLoadingMessage(n),i=this.renderMessage(a),o=i.querySelector('.message-content'),r=!0),a.content+=s.response;const t=this.formatMessage(a.content);e&&(console.log('🔢 累积内容:',a.content),console.log('🔢 格式化后:',t),console.log('🔢 格式化后包含数字:',/\d/.test(t))),o.innerHTML=t,requestAnimationFrame(()=>{
                  this.scrollToBottom();
                });
              }
            }catch(e){}
          }
        }
      }
    }finally{
      t.releaseLock();
    }a.content.trim()&&(this.messages.push(a),this.showShareButton()),this.setLoading(!1);
  }getCurrentLang(){
    if(window.i18n){
      return window.i18n.getCurrentLanguage();
    }const e=document.getElementById('btnEn');return e&&e.classList.contains('active')?'en':'zh-CN';
  }getTranslation(e){
    const n=this.getCurrentLang();return'undefined'===typeof translations?this.getFallbackTranslation(e,n):translations[n]?translations[n][e]:this.getFallbackTranslation(e,n);
  }getFallbackTranslation(e,n){
    const t={'zh-CN':{chat_input_placeholder:'问我关于AI创投的任何问题...',chat_welcome_title:'您好！我是凯瑞(Kerry)，SVTR的AI助手，专注于AI创投生态系统分析。',chat_welcome_content:'我可以为您提供：\n• 最新AI创投市场动态\n• 投资机构和初创公司分析  \n• 行业趋势和技术评估\n• 专业投资建议\n\n请问您想了解什么？',chat_user_name:'您',chat_ai_name:'凯瑞 (Kerry)',chat_thinking:'正在分析',chat_share_btn:'分享',chat_clear_btn:'清空'},en:{chat_input_placeholder:'Ask me anything about AI venture capital...',chat_welcome_title:'Hello! I\'m Kerry, SVTR assistant, specializing in AI venture capital ecosystem analysis.',chat_welcome_content:'I can provide you with:\n• Latest AI VC market dynamics\n• Investment firms and startup analysis\n• Industry trends and technology assessments  \n• Professional investment insights\n\nWhat would you like to know?',chat_user_name:'You',chat_ai_name:'Kerry',chat_thinking:'Analyzing',chat_share_btn:'Share',chat_clear_btn:'Clear'}};return t[n]?t[n][e]:e;
  }getSmartDemoResponse(e){
    const n=this.getCurrentLang(),t=this.matchResponseBySemantic(e,n);return this.getRelevantDemoResponse(e,t,n);
  }matchResponseBySemantic(e,n){
    const t=e.toLowerCase();if(/^\s*\d+\s*[+\-*/=()]+\s*\d*\s*=?\s*$/.test(e)||['加','减','乘','除','等于','plus','minus','times','divided','equals'].some(e=>t.includes(e))||/\d+\s*[+\-*/]\s*\d+/.test(e)){
      return'math_question';
    }const s={zh:['年','什么年','哪一年','哪年','年份','今年','明年','去年'],en:['year','what year','which year','when','annual','yearly']};if(('en'===n?s.en:[...s.zh,...s.en]).some(e=>t.includes(e))){
      return'year_question';
    }const a={investment:{zh:['投资','融资','资金','轮次','估值','基金','vc','投资人','投资机构','资本'],en:['investment','funding','capital','round','valuation','fund','investor','vc','venture']},startup:{zh:['公司','初创','创业','企业','团队','独角兽','项目','商业模式'],en:['startup','company','business','team','unicorn','entrepreneur','venture','firm']},trend:{zh:['趋势','市场','发展','前景','预测','未来','行业','报告','分析'],en:['trend','market','forecast','future','analysis','industry','outlook','prediction']},technology:{zh:['技术','科技','ai','人工智能','算法','模型','数据','平台','工具'],en:['technology','tech','ai','artificial intelligence','algorithm','model','data','platform']}};let i='general',o=0;return Object.keys(a).forEach(e=>{
      const s=a[e],r='en'===n?s.en:[...s.zh,...s.en];let c=0;r.forEach(e=>{
        t.includes(e)&&(e.length>4?c+=3:e.length>2?c+=2:c+=1);
      }),c>o&&(o=c,i=e);
    }),i;
  }getRelevantDemoResponse(e,n,t){
    const s=this.getVariedDemoResponses(t),a=s[n]||s.general;let i;if(1===a.length){
      i=a[0];
    }else{
      i=a[this.hashString(e)%a.length];
    }if('general'!==n){
      return('en'===t?'Based on your question about AI venture capital:\n\n':'关于您的AI创投问题：\n\n')+i;
    }return i;
  }hashString(e){
    let n=0;for(let t=0;t<e.length;t++){
      n=(n<<5)-n+e.charCodeAt(t),n&=n;
    }return Math.abs(n);
  }getVariedDemoResponses(e){
    return'en'===e?{math_question:['I\'m an AI venture capital assistant focused on AI investment analysis. For mathematical calculations, I\'d recommend:\n\n• **Simple math**: 1+1=2 ✓\n• **For complex calculations**: Use specialized tools or calculators\n• **For AI-related financial modeling**: I can help with investment valuations and market analysis\n\nWould you like to know about AI venture capital trends, funding rounds, or startup valuations instead? I have comprehensive data on the AI investment ecosystem!'],investment:['Based on SVTR\'s latest analysis, AI venture capital is experiencing unprecedented growth:\n\n**Key Investment Trends**:\n• **Funding Volume**: $50B+ invested in AI startups in 2024\n• **Hot Sectors**: Generative AI, autonomous systems, AI infrastructure\n• **Geographic Distribution**: 45% US, 25% China, 15% Europe, 15% Others\n• **Stage Focus**: Series A and B rounds showing strongest growth\n\n**Notable Recent Deals**:\n• Anthropic: $6B Series D (Amazon, Google participation)  \n• Scale AI: $1B Series E (preparing for IPO)\n• Perplexity: $250M Series B (enterprise AI search)\n\nThe market shows continued investor confidence in AI transformation across industries.','From an investor perspective, the AI venture landscape is rapidly maturing:\n\n**Investment Patterns**:\n• **Mega Rounds**: $100M+ funding becoming standard for AI leaders\n• **Valuation Metrics**: Revenue multiples reaching 20-50x for growth-stage AI\n• **Due Diligence Focus**: Technical moats, data advantages, and go-to-market strategy\n• **Exit Opportunities**: IPO pipeline building with 10+ AI unicorns preparing\n\n**Strategic Considerations**:\n• Enterprise adoption driving B2B AI valuations\n• Infrastructure plays gaining premium valuations\n• Regulatory compliance becoming key differentiator\n• AI talent acquisition costs impacting unit economics\n\nCurrent market dynamics favor companies with proven revenue traction and clear paths to profitability.','SVTR\'s investment database reveals shifting capital allocation patterns:\n\n**Sector Rotation**:\n• **From** Consumer AI → **To** Enterprise Solutions\n• **From** Large Models → **To** Application Layer\n• **From** Generative AI → **To** Specialized AI Tools\n• **Stage Preference**: Growth equity over early-stage speculation\n\n**Risk Assessment**:\n• Market saturation in consumer generative AI\n• Regulatory headwinds affecting model development\n• Talent costs pressuring unit economics\n• Competition from Big Tech internal development\n\nSmart money is focusing on defensible AI applications with clear ROI metrics.'],startup:['SVTR tracks 10,761 AI companies globally. Here\'s the current startup landscape:\n\n**Emerging AI Unicorns**:\n• **Enterprise AI**: Scale AI, Databricks leading with $1B+ valuations\n• **Generative AI**: OpenAI, Anthropic, Midjourney dominating creative markets\n• **AI Infrastructure**: Nvidia, AMD, custom chip makers driving hardware innovation\n• **Vertical AI**: Healthcare, finance, automotive applications showing strong growth\n\n**Success Patterns**:\n• Strong technical teams with AI/ML expertise\n• Clear path to enterprise revenue models\n• Defensible data advantages and network effects\n• Scalable technology platforms with API-first approach\n\nCurrent valuations reflect both massive opportunity and market maturity expectations.','Analyzing successful AI startups reveals key differentiation strategies:\n\n**Competitive Positioning**:\n• **Data Moats**: Proprietary datasets creating unique training advantages\n• **Technical Excellence**: PhD-level talent from top research institutions\n• **Go-to-Market**: Enterprise sales teams with domain expertise\n• **Capital Efficiency**: Lean operations leveraging cloud infrastructure\n\n**Growth Metrics**:\n• ARR growth rates of 300-500% for top performers\n• Customer acquisition costs dropping with product maturity\n• Net revenue retention exceeding 120% for enterprise-focused companies\n• Time to value under 30 days for successful implementations\n\nThe winners are building sustainable competitive advantages beyond just AI capabilities.'],trend:['Current AI venture capital trends reveal market evolution patterns:\n\n**Market Dynamics**:\n• **Consolidation Phase**: Fewer but larger funding rounds ($50M+ becoming standard)\n• **Enterprise Focus**: B2B AI solutions commanding premium valuations\n• **Vertical Specialization**: Industry-specific AI applications gaining traction\n• **Infrastructure Investment**: AI chip and cloud infrastructure seeing massive inflows\n\n**Emerging Opportunities**:\n• AI agents and automation platforms\n• Multimodal AI applications combining vision, text, audio\n• Edge AI and mobile implementations\n• AI safety and governance tools\n\nThe market is maturing toward sustainable, revenue-generating AI businesses with clear unit economics.','SVTR\'s trend analysis highlights shifting investor priorities:\n\n**Investment Evolution**:\n• **2023**: Generative AI hype cycle peaks\n• **2024**: Enterprise adoption focus emerges\n• **2025**: Profitable AI applications prioritized\n\n**Geographic Shifts**:\n• US maintaining 45% market share but growth slowing\n• Europe gaining ground with regulatory clarity\n• Asia focusing on manufacturing and robotics AI\n• Emerging markets developing localized AI solutions\n\n**Sector Rotation Patterns**:\n• Consumer AI → Enterprise solutions\n• General purpose → Specialized applications  \n• Model development → Application layer innovation\n• Venture capital → Growth equity preference\n\nSmart investors are positioning for the next phase of AI commercialization.'],technology:['Technical analysis from SVTR\'s research team:\n\n**Core Technology Trends**:\n• **Large Language Models**: GPT-5, Claude-3, Gemini advancing reasoning capabilities\n• **Multimodal AI**: Vision, audio, text integration becoming industry standard\n• **Edge Computing**: On-device AI processing reducing cloud dependency and latency\n• **Custom Silicon**: AI-specific chips improving performance/efficiency ratios by 10x\n\n**Investment Implications**:\n• Companies with proprietary data advantages commanding premium valuations\n• Platforms enabling AI democratization seeing massive adoption\n• Infrastructure supporting AI workloads experiencing supply constraints\n• Developer tools for AI deployment becoming critical bottlenecks\n\nTechnology differentiation remains the key driver of sustainable competitive advantages.','From a technical investment perspective, the AI stack is consolidating:\n\n**Architecture Evolution**:\n• **Model Layer**: Foundation models becoming commoditized utilities\n• **Application Layer**: Where most value creation and capture occurs\n• **Infrastructure Layer**: Critical but capital-intensive with lower margins\n• **Data Layer**: Increasingly recognized as the primary moat\n\n**Technical Risk Factors**:\n• Model performance plateauing without architectural breakthroughs\n• Training costs increasing exponentially with model size\n• Inference optimization becoming competitive necessity\n• Regulatory constraints on data usage and model deployment\n\nThe next wave of AI investing will focus on companies solving real business problems rather than just advancing model capabilities.'],year_question:['2024 is a pivotal year for AI venture capital! Based on SVTR\'s analysis:\n\n**2024 AI VC Characteristics**:\n• **Capital Concentration**: Over $50B in total funding, concentrated in leading companies\n• **Enterprise Focus**: Shift from consumer AI to enterprise applications and solutions\n• **Technology Maturity**: Transition from proof-of-concept to commercialization and profitability\n• **Regulatory Clarity**: Global AI governance frameworks taking shape, compliance becoming key\n\n**Key Milestones**:\n• OpenAI, Anthropic and other leaders achieving $100B+ valuations\n• 45+ new AI unicorns born with total valuation exceeding $100B\n• Enterprise AI adoption exceeding 80% among Fortune 500\n• AI infrastructure investments reaching historic highs\n\n2024 marks the crucial transition from speculation to value creation in AI venture capital.','From an investment perspective, 2024 is the "maturation year" for AI venture markets:\n\n**Market Evolution**:\n• **Investment Rationalization**: From blind hype to focus on actual value and ROI\n• **Sector Specialization**: Vertical AI applications receiving more attention and capital\n• **Technical Barriers**: Data advantages and expertise becoming core competitive moats\n• **Exit Channels**: IPO and M&A markets providing clear exit paths for AI companies\n\n**2024 Key Metrics**:\n• Total AI VC funding: $50+B (35% YoY growth)\n• New unicorns: 45 AI companies exceeding $1B valuation\n• Average round sizes: Series A $25M, Series B $60M\n• Exit cases: 12 AI companies successfully IPO\'d, total market cap $200+B\n\nThis year witnessed the acceleration of AI\'s commercialization journey from concept to reality.'],general:['Welcome to SVTR\'s comprehensive AI venture capital analysis platform:\n\n**Platform Overview**:\n• **Community**: 121,884+ AI professionals and investors globally\n• **Database**: 10,761 tracked AI companies with real-time updates\n• **Coverage**: Complete global AI investment ecosystem mapping\n• **Focus**: Strategic investment insights and professional networking\n\n**Our Services**:\n• **AI Investment Database**: Detailed company profiles, funding data, market analysis\n• **AI Investment Conference**: Premium industry networking and deal-making events\n• **AI Investment Camp**: Executive education programs for sophisticated investors\n\n**Recent Market Highlights**:\n• Q4 2024: $12B in AI venture funding across 200+ deals\n• 45+ new AI unicorns achieved $1B+ valuations this year\n• Enterprise AI adoption rates exceeding 80% among Fortune 500\n• Regulatory frameworks driving AI safety and governance investments','SVTR provides institutional-grade AI investment intelligence:\n\n**Market Intelligence**:\n• Real-time funding announcements and valuation data\n• Technical due diligence frameworks for AI investments\n• Competitive landscape mapping and positioning analysis\n• Exit opportunity tracking including IPO and M&A pipelines\n\n**Investment Network**:\n• Direct access to 100+ active AI-focused VCs\n• LP introductions to top-tier AI investment funds\n• Entrepreneur-investor matching based on sector expertise\n• Deal syndication opportunities for qualified participants\n\n**Research Products**:\n• Weekly AI investment market updates and analysis\n• Quarterly deep-dive reports on emerging AI sectors\n• Annual AI venture capital market state analysis\n• Custom research engagements for institutional clients\n\nOur platform serves as the definitive source for AI investment market intelligence and networking.'],supplements:{investment:['**Additional Market Context**: Current AI investment concentration shows 80% of funding going to just 20% of companies, indicating a winner-take-all dynamic similar to previous technology cycles.','**Regulatory Impact**: Recent AI governance frameworks in EU and US are creating compliance costs but also barriers to entry that benefit well-funded incumbents.','**Global Dynamics**: Chinese AI investments have declined 40% due to export restrictions, while European AI funding has grown 150% year-over-year.'],startup:['**Talent Wars**: AI engineer compensation has increased 60% year-over-year, with signing bonuses reaching $500K+ for senior ML engineers at top startups.','**Technical Moats**: Companies building on proprietary datasets are achieving 3x higher valuations than those relying on public data sources.','**Customer Concentration**: Most successful AI startups derive 60%+ revenue from enterprise customers with $1B+ annual revenue.'],trend:['**Cyclical Patterns**: AI investment cycles are shortening from 18-month to 12-month periods, driven by rapid technology advancement.','**Sector Maturity**: Enterprise AI categories are reaching Series B/C maturity while consumer AI remains early-stage experimental.','**Geographic Arbitrage**: Emerging markets offering 70% cost advantages for AI development talent while maintaining comparable quality.'],technology:['**Performance Benchmarks**: Latest AI models are achieving human-level performance on 90%+ of standardized cognitive tasks, but real-world deployment remains challenging.','**Infrastructure Costs**: Training costs for frontier models have increased 10x annually, creating natural barriers to entry for new model developers.','**Open Source Impact**: Open-source AI models are commoditizing basic capabilities while specialized applications maintain pricing power.']}}:{math_question:['我是SVTR的AI创投分析师，专注于AI投资分析。对于数学计算，我建议：\n\n• **简单数学**：1+1=2 ✓\n• **复杂计算**：使用专业计算器工具\n• **AI相关的财务建模**：我可以帮助投资估值和市场分析\n\n您想了解AI创投趋势、融资轮次或初创公司估值吗？我拥有全面的AI投资生态系统数据！'],investment:['基于SVTR最新分析，AI创投正经历前所未有的增长：\n\n**核心投资趋势**：\n• **资金规模**：2024年AI初创公司融资超过500亿美元\n• **热门赛道**：生成式AI、自动驾驶、AI基础设施\n• **地理分布**：美国45%，中国25%，欧洲15%，其他15%\n• **轮次重点**：A轮和B轮表现最为活跃\n\n**近期重大交易**：\n• Anthropic：60亿美元D轮（亚马逊、谷歌参投）\n• Scale AI：10亿美元E轮（准备IPO）\n• Perplexity：2.5亿美元B轮（企业级AI搜索）\n\n市场显示投资者对AI行业转型持续保持信心。','从投资人视角看，AI创投生态正快速成熟：\n\n**投资模式变化**：\n• **大额融资**：1亿美元以上轮次成为AI头部公司标配\n• **估值倍数**：成长期AI公司收入倍数达到20-50倍\n• **尽调重点**：技术护城河、数据优势、市场拓展策略\n• **退出机会**：10+AI独角兽正准备IPO\n\n**战略考量**：\n• 企业级应用推动B2B AI估值上升\n• 基础设施投资获得溢价估值\n• 合规要求成为关键差异化因素\n• AI人才获取成本影响单位经济模型\n\n当前市场动态偏向有proven收入牵引力和明确盈利路径的公司。'],startup:['SVTR追踪全球10,761家AI公司。当前初创企业格局：\n\n**新兴AI独角兽**：\n• **企业级AI**：Scale AI、Databricks等以10亿美元+估值领先\n• **生成式AI**：OpenAI、Anthropic、Midjourney主导创意市场\n• **AI基础设施**：英伟达、AMD、定制芯片制造商推动硬件创新\n• **垂直AI应用**：医疗、金融、汽车等领域应用增长强劲\n\n**成功模式**：\n• 拥有AI/ML专业技术团队\n• 清晰的企业级收入模式\n• 可防御的数据优势和网络效应\n• API优先的可扩展技术平台\n\n当前估值反映了巨大机遇与市场成熟度预期的平衡。','分析成功AI初创企业揭示关键差异化策略：\n\n**竞争定位**：\n• **数据护城河**：专有数据集创造独特训练优势\n• **技术卓越**：顶尖研究机构的博士级人才\n• **市场开拓**：具备领域专长的企业销售团队\n• **资本效率**：利用云基础设施的精益运营\n\n**增长指标**：\n• 头部公司ARR增长率300-500%\n• 随产品成熟客户获取成本下降\n• 企业级公司净收入留存率超过120%\n• 成功实施的价值实现时间少于30天\n\n胜出者正在构建超越AI能力本身的可持续竞争优势。'],trend:['SVTR分析的当前AI创投趋势揭示市场演进模式：\n\n**市场动态**：\n• **整合阶段**：融资轮次减少但规模更大（5000万美元+成为标准）\n• **企业级重点**：B2B AI解决方案获得溢价估值\n• **垂直专业化**：行业特定AI应用获得牵引力\n• **基础设施投资**：AI芯片和云基础设施见证大量资金流入\n\n**新兴机会**：\n• AI智能体和自动化平台\n• 结合视觉、文本、音频的多模态AI应用\n• 边缘AI和移动端实现\n• AI安全和治理工具\n\n市场正向具有清晰单位经济模型的可持续、有收入的AI业务成熟。','SVTR趋势分析突出投资者优先级的转变：\n\n**投资演进**：\n• **2023年**：生成式AI炒作周期达到顶峰\n• **2024年**：企业级采用焦点出现\n• **2025年**：盈利AI应用获得优先考虑\n\n**地理转移**：\n• 美国保持45%市场份额但增长放缓\n• 欧洲凭借监管明确性获得优势\n• 亚洲专注制造业和机器人AI\n• 新兴市场开发本地化AI解决方案\n\n**赛道轮换模式**：\n• 消费AI → 企业解决方案\n• 通用目的 → 专业化应用\n• 模型开发 → 应用层创新\n• 风险投资 → 成长股权偏好\n\n聪明的投资者正为AI商业化的下一阶段定位。'],technology:['SVTR技术研究团队分析：\n\n**核心技术趋势**：\n• **大语言模型**：GPT-5、Claude-3、Gemini推进推理能力\n• **多模态AI**：视觉、音频、文本集成成为行业标准\n• **边缘计算**：设备端AI处理减少云依赖和延迟\n• **定制芯片**：AI专用芯片将性能/效率比提升10倍\n\n**投资影响**：\n• 拥有专有数据优势的公司获得溢价估值\n• 实现AI民主化的平台见证大规模采用\n• 支持AI工作负载的基础设施经历供应约束\n• AI部署开发工具成为关键瓶颈\n\n技术差异化仍是可持续竞争优势的关键驱动因素。','从技术投资角度看，AI技术栈正在整合：\n\n**架构演进**：\n• **模型层**：基础模型成为商品化公用事业\n• **应用层**：大部分价值创造和捕获发生的地方\n• **基础设施层**：关键但资本密集，利润率较低\n• **数据层**：越来越被认为是主要护城河\n\n**技术风险因素**：\n• 模型性能在没有架构突破的情况下趋于平稳\n• 训练成本随模型大小指数级增长\n• 推理优化成为竞争必需品\n• 数据使用和模型部署的监管约束\n\n下一波AI投资将专注于解决真实商业问题的公司，而不仅仅是推进模型能力。'],year_question:['2024年是AI创投发展的关键转折年！根据SVTR数据分析：\n\n**2024年AI创投特点**：\n• **资本集中**：总融资额超过500亿美元，但集中在头部公司\n• **企业聚焦**：从消费级AI转向企业级应用和解决方案\n• **技术成熟**：从概念验证转向商业化落地和盈利模式\n• **监管明确**：全球AI治理框架逐步完善，合规成为关键\n\n**关键里程碑**：\n• OpenAI、Anthropic等头部公司获得百亿美元估值\n• 45+家新AI独角兽诞生，总估值超过1000亿美元\n• 企业级AI采用率在Fortune 500中超过80%\n• AI基础设施投资创历史新高\n\n2024年标志着AI创投从投机转向价值创造的重要转型期。','从投资角度看，2024年是AI创投市场的"成熟元年"：\n\n**市场演变**：\n• **投资理性化**：从盲目追热点转向关注实际价值和ROI\n• **赛道细分**：垂直领域AI应用获得更多关注和资本\n• **技术门槛**：数据优势和专业知识成为核心竞争力\n• **退出通道**：IPO和并购市场为AI公司提供明确退出路径\n\n**2024年关键数据**：\n• AI创投总额：500+亿美元（同比增长35%）\n• 新增独角兽：45家AI公司估值超过10亿美元\n• 平均轮次规模：A轮2500万美元，B轮6000万美元\n• 退出案例：12家AI公司成功IPO，总市值超过2000亿美元\n\n这一年见证了AI从概念走向现实的商业化进程加速。'],general:['欢迎来到SVTR全面的AI创投分析平台：\n\n**平台概况**：\n• **社区规模**：121,884+全球AI专业人士和投资者\n• **数据库**：追踪10,761家AI公司，实时更新\n• **覆盖范围**：完整的全球AI投资生态系统映射\n• **专业重点**：战略投资洞察和专业网络\n\n**我们的服务**：\n• **AI创投库**：详细公司档案、融资数据、市场分析\n• **AI创投会**：高端行业网络和交易撮合活动\n• **AI创投营**：面向资深投资者的高管教育项目\n\n**近期市场亮点**：\n• 2024年Q4：120亿美元AI创投资金，覆盖200+交易\n• 今年新增45+AI独角兽实现10亿美元+估值\n• 财富500强企业AI采用率超过80%\n• 监管框架推动AI安全和治理投资','SVTR提供机构级AI投资情报：\n\n**市场情报**：\n• 实时融资公告和估值数据\n• AI投资技术尽调框架\n• 竞争格局映射和定位分析\n• 退出机会追踪，包括IPO和M&A管道\n\n**投资网络**：\n• 直接接触100+活跃AI专注VC\n• 向顶级AI投资基金LP介绍\n• 基于行业专长的企业家-投资者匹配\n• 合格参与者的交易联合机会\n\n**研究产品**：\n• 每周AI投资市场更新和分析\n• 新兴AI领域季度深度报告\n• 年度AI创投市场状况分析\n• 面向机构客户的定制研究服务\n\n我们的平台是AI投资市场情报和网络的权威来源。'],supplements:{investment:['**附加市场背景**：当前AI投资集中度显示80%资金流向仅20%的公司，表明类似于之前技术周期的赢者通吃动态。','**监管影响**：欧盟和美国最新AI治理框架正在创造合规成本，但也为资金充足的现有企业创造了进入壁垒。','**全球动态**：由于出口限制，中国AI投资下降40%，而欧洲AI融资同比增长150%。'],startup:['**人才争夺**：AI工程师薪酬同比增长60%，顶级初创企业高级ML工程师签约奖金达到50万美元+。','**技术护城河**：基于专有数据集构建的公司估值比依赖公共数据源的公司高3倍。','**客户集中度**：最成功的AI初创企业60%+收入来自年收入10亿美元+的企业客户。'],trend:['**周期性模式**：AI投资周期正从18个月缩短到12个月周期，由快速技术进步驱动。','**行业成熟度**：企业AI类别正达到B/C轮成熟度，而消费AI仍处于早期实验阶段。','**地理套利**：新兴市场为AI开发人才提供70%成本优势，同时保持可比质量。'],technology:['**性能基准**：最新AI模型在90%+标准化认知任务上达到人类水平性能，但现实世界部署仍具挑战性。','**基础设施成本**：前沿模型训练成本每年增长10倍，为新模型开发者创造自然进入壁垒。','**开源影响**：开源AI模型正在将基础能力商品化，而专业应用保持定价权。']}};
  }init(){
    this.createChatInterface(),this.bindEvents(),this.setupTextareaAutoResize(),this.setupLanguageListener(),this.addWelcomeMessage();
  }createChatInterface(){
    this.container.innerHTML=`\n      <div class="svtr-chat-container">\n        <div class="svtr-chat-messages" id="svtr-chat-messages">\n          \x3c!-- 消息将在这里显示 --\x3e\n        </div>\n        \n        <div class="svtr-chat-input-area">\n          <div class="svtr-chat-input-container">\n            <textarea \n              id="svtr-chat-input" \n              data-testid="chat-input"\n              placeholder="${this.getTranslation('chat_input_placeholder')}"\n              maxlength="1000"\n              rows="1"\n            ></textarea>\n            <button id="svtr-chat-send" data-testid="chat-send" class="svtr-chat-send-btn">\n              <span class="send-icon">↑</span>\n            </button>\n          </div>\n          <div class="svtr-chat-actions">\n            <button id="svtr-share-btn" class="svtr-action-btn" style="display: none;">\n              <span>📤</span> ${this.getTranslation('chat_share_btn')}\n            </button>\n            <button id="svtr-clear-btn" class="svtr-action-btn">\n              <span>🗑</span> ${this.getTranslation('chat_clear_btn')}\n            </button>\n          </div>\n        </div>\n      </div>\n    `;
  }bindEvents(){
    const e=document.getElementById('svtr-chat-input'),n=document.getElementById('svtr-chat-send'),t=document.getElementById('svtr-share-btn'),s=document.getElementById('svtr-clear-btn');n.addEventListener('click',()=>this.sendMessage()),e.addEventListener('keypress',e=>{
      'Enter'!==e.key||e.shiftKey||(e.preventDefault(),this.sendMessage());
    }),t.addEventListener('click',()=>this.shareConversation()),s.addEventListener('click',()=>this.clearChat());
  }setupTextareaAutoResize(){
    const e=document.getElementById('svtr-chat-input'),n=document.getElementById('svtr-chat-send');e.addEventListener('input',()=>{
      e.style.height='44px',e.style.height=Math.min(e.scrollHeight,120)+'px',n.style.opacity=e.value.trim()?'1':'0.5';
    }),n.style.opacity='0.5';
  }setupLanguageListener(){
    document.addEventListener('languageChanged',()=>{
      this.updateInterfaceLanguage();
    });
  }updateInterfaceLanguage(){
    const e=document.getElementById('svtr-chat-input');e&&(e.placeholder=this.getTranslation('chat_input_placeholder')),this.createChatInterface(),this.bindEvents(),this.setupTextareaAutoResize(),this.updateWelcomeMessage(),this.rerenderMessages();
  }rerenderMessages(){
    document.getElementById('svtr-chat-messages').innerHTML='',this.messages.forEach(e=>{
      this.renderMessage(e);
    });
  }addWelcomeMessage(){
    let e=`${this.getTranslation('chat_welcome_title')}\n\n${this.getTranslation('chat_welcome_content')}`;if(this.isProduction){
      e+='en'===this.getCurrentLang()?'\n\n*This is an intelligent demo showcasing SVTR\'s analysis capabilities. Ask me about AI venture capital trends, companies, or investment insights!*':'\n\n*这是SVTR分析能力的智能演示。请询问AI创投趋势、公司信息或投资洞察！*';
    }const n={role:'assistant',content:e,timestamp:new Date};this.messages.push(n),this.renderMessage(n);
  }async sendMessage(){
    const e=document.getElementById('svtr-chat-input'),n=e.value.trim();if(!n||this.isLoading){
      return;
    }this.isProduction&&this.updateQuotaStatus();const t={role:'user',content:n,timestamp:new Date};this.messages.push(t),this.renderMessage(t),e.value='',e.style.height='44px',this.setLoading(!0),this.isThinking=!1;const s=this.showLoadingMessage();this.isProduction?this.tryRealAPIFirst(n,s).then(e=>{
      e||setTimeout(()=>{
        this.removeLoadingMessage(s);const e={role:'assistant',content:this.getSmartDemoResponse(n),timestamp:new Date};this.messages.push(e),this.renderMessage(e),this.showShareButton(),this.setLoading(!1);
      },1e3+2e3*Math.random());
    }):(console.log('本地开发环境，使用演示模式'),setTimeout(()=>{
      this.removeLoadingMessage(s);const e={role:'assistant',content:this.getSmartDemoResponse(n),timestamp:new Date};this.messages.push(e),this.renderMessage(e),this.showShareButton(),this.setLoading(!1);
    },800+1200*Math.random()));
  }renderMessage(e){
    const n=document.getElementById('svtr-chat-messages'),t=document.createElement('div');t.className=`svtr-message ${e.role}`;const s='user'===e.role,a=s?'U':'AI',i=s?'您':'凯瑞 (Kerry)';return t.innerHTML=`\n      <div class="message-header">\n        <div class="message-avatar">${a}</div>\n        <span class="message-name">${i}</span>\n        <span class="message-time">${this.formatTime(e.timestamp)}</span>\n      </div>\n      <div class="message-content">${this.formatMessage(e.content)}</div>\n    `,n.appendChild(t),n.scrollTop=n.scrollHeight,t;
  }showLoadingMessage(){
    const e=document.getElementById('svtr-chat-messages'),n=document.createElement('div');return n.className='svtr-message assistant loading',n.innerHTML=`\n      <div class="message-header">\n        <div class="message-avatar">AI</div>\n        <span class="message-name">${this.getTranslation('chat_ai_name')}</span>\n        <span class="message-time">${this.formatTime(new Date)}</span>\n      </div>\n      <div class="message-content">\n        <div class="loading-dots">\n          <span class="thinking-emoji">●</span>\n          ${this.getTranslation('chat_thinking')}\n          <span class="animated-dots">\n            <span>.</span><span>.</span><span>.</span>\n          </span>\n        </div>\n      </div>\n    `,e.appendChild(n),e.scrollTop=e.scrollHeight,n;
  }removeLoadingMessage(e){
    e&&e.parentNode&&e.parentNode.removeChild(e);
  }showErrorMessage(e){
    const n={role:'assistant',content:`❌ ${e}`,timestamp:new Date};this.renderMessage(n);
  }formatMessage(e){
    return e.replace(/\*\*(.*?)\*\*/g,'<strong>$1</strong>').replace(/\*(.*?)\*/g,'<em>$1</em>').replace(/\n/g,'<br>').replace(/•/g,'•');
  }formatTime(e){
    return e.toLocaleTimeString('zh-CN',{hour:'2-digit',minute:'2-digit'});
  }setLoading(e){
    this.isLoading=e;const n=document.getElementById('svtr-chat-send'),t=document.getElementById('svtr-chat-input');n.disabled=e,t.disabled=e,e?n.innerHTML='<span class="loading-spinner">⟳</span>':(n.innerHTML='<span class="send-icon">↑</span>',setTimeout(()=>{
      t&&!t.disabled&&t.focus();
    },100));
  }showShareButton(){
    const e=document.getElementById('svtr-share-btn');this.messages.length>2&&(e.style.display='inline-flex');
  }shareConversation(){
    const e=this.messages.filter(e=>'user'===e.role).pop(),n=this.messages.filter(e=>'assistant'===e.role).pop();if(!e||!n){
      return;
    }const t=`💡 来自SVTR的AI创投洞察：\n\n🔍 问题：${e.content}\n\n🤖 AI分析：${n.content.substring(0,200)}${n.content.length>200?'...':''}\n\n--\n生成于 ${(new Date).toLocaleString('zh-CN')}\n来源：SVTR (https://svtr.ai)`;navigator.clipboard.writeText(t).then(()=>{
      this.showToast('内容已复制到剪贴板，快去AI创投会分享吧！');
    }).catch(()=>{
      this.showShareDialog(t);
    });
  }showShareDialog(e){
    const n=document.createElement('div');n.className='svtr-share-dialog',n.innerHTML=`\n      <div class="share-dialog-content">\n        <h4>分享到AI创投会</h4>\n        <textarea readonly>${e}</textarea>\n        <div class="share-actions">\n          <button onclick="this.parentElement.parentElement.parentElement.remove()">关闭</button>\n        </div>\n      </div>\n    `,document.body.appendChild(n);
  }showToast(e){
    const n=document.createElement('div');n.className='svtr-toast',n.textContent=e,document.body.appendChild(n),setTimeout(()=>{
      n.remove();
    },3e3);
  }scrollToBottom(){
    const e=document.getElementById('svtr-chat-messages');e.scrollTop=e.scrollHeight;
  }clearChat(){
    this.messages=[],document.getElementById('svtr-chat-messages').innerHTML='',document.getElementById('svtr-share-btn').style.display='none',this.addWelcomeMessage();
  }updateWelcomeMessage(){
    if(this.messages.length>0&&'assistant'===this.messages[0].role){
      let e=`${this.getTranslation('chat_welcome_title')}\n\n${this.getTranslation('chat_welcome_content')}`;if(this.isProduction){
        e+='en'===this.getCurrentLang()?'\n\n*This is an intelligent demo showcasing SVTR\'s analysis capabilities. Ask me about AI venture capital trends, companies, or investment insights!*':'\n\n*这是SVTR分析能力的智能演示。请询问AI创投趋势、公司信息或投资洞察！*';
      }this.messages[0].content=e;
    }
  }async updateQuotaStatus(){
    try{
      const e=await fetch('/api/quota-status');if(e.ok){
        const n=await e.json();this.displayQuotaInfo(n);
      }
    }catch(e){
      console.log('无法获取配额状态:',e);
    }
  }displayQuotaInfo(e){
    if(e.quotas.daily.percentage>80||e.quotas.monthly.percentage>80){
      const n={role:'system',content:`⚡ **免费额度提醒**：\n• 日使用量：${e.quotas.daily.used}/${e.quotas.daily.limit} (${e.quotas.daily.percentage}%)\n• 月使用量：${e.quotas.monthly.used}/${e.quotas.monthly.limit} (${e.quotas.monthly.percentage}%)\n\n${e.message}${e.upgradeHint?'\n\n'+e.upgradeHint:''}`,timestamp:new Date};this.quotaWarningShown||(this.renderMessage(n),this.quotaWarningShown=!0);
    }
  }
}document.addEventListener('DOMContentLoaded',function(){
  document.getElementById('svtr-chat-container')&&('undefined'!==typeof translations?window.svtrChat=new SVTRChat('svtr-chat-container'):setTimeout(()=>{
    window.svtrChat=new SVTRChat('svtr-chat-container');
  },100));
});
